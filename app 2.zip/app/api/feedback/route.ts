
import OpenAI from "openai";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import { prisma } from "@/app/lib/prisma";

export const runtime = "nodejs";

type FeedbackJSON = {
  score: number;
  communication_score: number;

  confidence_score: number;
  confidence_explanation: string;

  star: {
    situation: number;
    task: number;
    action: number;
    result: number;
  };

  star_missing: Array<"situation" | "task" | "action" | "result">;

  star_advice: {
    situation: string;
    task: string;
    action: string;
    result: string;
  };

  strengths: string[];
  improvements: string[];
  better_answer: string;
  keywords_missing: string[];
  keywords_used:string[]
};

// (optional) response type you actually return after you append filler
type FeedbackResponse = FeedbackJSON & {
  filler: {
    total: number;
    words: number;
    per100: number;
    top: string[];
  };
};



function tryParseJson(s: string) {
  try {
    return JSON.parse(s);
  } catch {
    return null;
  }
}

function extractFirstJsonObject(text: string) {
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start === -1 || end === -1 || end <= start) return null;
  return text.slice(start, end + 1);
}

function isNonEmptyString(x: unknown) {
  return typeof x === "string" && x.trim().length > 0;
}

function validateFeedbackShape(obj: any): obj is FeedbackJSON {
  if (typeof obj !== "object" || obj === null) return false;

  // score
  if (typeof obj.score !== "number" || !Number.isFinite(obj.score)) return false;
  if (obj.score < 1 || obj.score > 10) return false;

  // communication score
  if (typeof obj.communication_score !== "number" || !Number.isFinite(obj.communication_score)) return false;
  if (obj.communication_score < 1 || obj.communication_score > 10) return false;

  // confidence score
if (typeof obj.confidence_score !== "number" || !Number.isFinite(obj.confidence_score)) return false;
if (obj.confidence_score < 1 || obj.confidence_score > 10) return false;

// confidence explanation
if (!isNonEmptyString(obj.confidence_explanation)) return false;


  // STAR
  if (typeof obj.star !== "object" || obj.star === null) return false;

  const starKeys = ["situation", "task", "action", "result"] as const;
  for (const k of starKeys) {
  const v = obj.star[k];
  if (typeof v !== "number" || !Number.isFinite(v)) return false;
  if (v < 0 || v > 10) return false;

}

  // star_missing
const allowed = new Set(["situation", "task", "action", "result"]);
if (!Array.isArray(obj.star_missing)) return false;
if (obj.star_missing.length > 4) return false;
if (!obj.star_missing.every((x: any) => typeof x === "string" && allowed.has(x))) return false;
// star_advice
if (typeof obj.star_advice !== "object" || obj.star_advice === null) return false;

for (const k of ["situation", "task", "action", "result"]) {
  if (!isNonEmptyString(obj.star_advice[k])) return false;
}




  // strengths / improvements
  if (!Array.isArray(obj.strengths) || !Array.isArray(obj.improvements)) return false;
  if (obj.strengths.length < 3 || obj.strengths.length > 5) return false;
  if (obj.improvements.length < 3 || obj.improvements.length > 5) return false;
  if (!obj.strengths.every(isNonEmptyString)) return false;
  if (!obj.improvements.every(isNonEmptyString)) return false;

  // better_answer
  if (!isNonEmptyString(obj.better_answer)) return false;

    // keywords_used
  if (!Array.isArray(obj.keywords_used)) return false;
  if (obj.keywords_used.length > 12) return false;
  if (!obj.keywords_used.every(isNonEmptyString)) return false;

  // keywords_missing
  if (!Array.isArray(obj.keywords_missing)) return false;
  if (obj.keywords_missing.length > 8) return false;
  if (!obj.keywords_missing.every(isNonEmptyString)) return false;

  return true;
}


const FILLERS = [
  "um", "uh", "like", "you know", "sort of", "kind of", "basically", "literally",
  "actually", "honestly", "so", "right", "i mean", "okay", "well"
];

function countFillers(transcript: string) {
  const t = transcript.toLowerCase();

  // Count multi-word fillers with word boundaries-ish
  let total = 0;
  const perFiller: Record<string, number> = {};

  for (const phrase of FILLERS) {
    const escaped = phrase.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    // Allow spaces in multiword fillers, enforce boundaries around first/last word.
    const pattern = phrase.includes(" ")
      ? new RegExp(`\\b${escaped.replace(/\s+/g, "\\s+")}\\b`, "g")
      : new RegExp(`\\b${escaped}\\b`, "g");

    const matches = t.match(pattern);
    const n = matches ? matches.length : 0;
    perFiller[phrase] = n;
    total += n;
  }

  // Word count (rough) + fillers per 100 words
  const words = transcript.trim().split(/\s+/).filter(Boolean);
  const wordCount = words.length;
  const per100 = wordCount > 0 ? (total / wordCount) * 100 : 0;

  // A simple penalty signal you can use (optional)
  // (keep penalty small; STAR content matters more)
  const penaltyPoints = Math.min(2.0, per100 * 0.15); // e.g., 10 fillers/100 words => 1.5 pts penalty (cap at 2)

  return { total, perFiller, wordCount, fillersPer100Words: per100, penaltyPoints };
  

}
const STOP = new Set([
  "the","and","or","a","an","to","of","in","for","on","with","as","at","by","from","into","that","this",
  "is","are","was","were","be","been","being","it","its","their","our","your","you","we","they","i",
  "will","would","should","can","could","may","might","must","not","no","yes","but","if","then","than",
  "about","over","under","between","within","across","per","via","etc"
]);

function normalizeText(s: string) {
  return (s || "")
    .toLowerCase()
    .replace(/[^a-z0-9\s/+.-]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function extractKeywords(jobDesc: string) {
  const text = normalizeText(jobDesc);
  const words = text.split(" ").filter(Boolean);

  const candidates = new Map<string, number>();

  // unigrams
  for (const w of words) {
    if (w.length >= 4 && !STOP.has(w)) {
      candidates.set(w, (candidates.get(w) ?? 0) + 1);
    }
  }

  // bigrams (phrases like "service level", "inventory planning")
  for (let i = 0; i < words.length - 1; i++) {
    const a = words[i], b = words[i + 1];
    if (STOP.has(a) || STOP.has(b)) continue;
    if (a.length < 3 || b.length < 3) continue;

    const phrase = `${a} ${b}`;
    candidates.set(phrase, (candidates.get(phrase) ?? 0) + 2);
  }

  return [...candidates.entries()]
    .sort((a, b) => b[1] - a[1])
    .map(([k]) => k)
    .slice(0, 20);
}

function computeKeywordUsage(jobDesc: string, transcript: string) {
  const jd = normalizeText(jobDesc);
  const tr = normalizeText(transcript);

  const keywords = extractKeywords(jd);

  const used: string[] = [];
  const missing: string[] = [];

  for (const k of keywords) {
    if (tr.includes(k)) used.push(k);
    else missing.push(k);
  }

  return {
    keywords_used: used.slice(0, 12),
    keywords_missing: missing.slice(0, 8),
  };
}
export async function POST(req: Request) {
  try {
    const { jobDesc, question, transcript } = await req.json();

    if (!transcript || typeof transcript !== "string" || transcript.trim().length < 10) {
      return new Response(JSON.stringify({ error: "Transcript is too short." }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      });
    }
    const fillerStats = countFillers(transcript);
    const kw = computeKeywordUsage(jobDesc ?? "", transcript);


    const topFillers = Object.entries(fillerStats.perFiller)
  .filter(([, n]) => n > 0)
  .sort((a, b) => b[1] - a[1])
  .slice(0, 5)
  .map(([k, n]) => `${k} (${n})`);

const session = await getServerSession(authOptions);
const email = session?.user?.email;
if (!email) return new Response("Unauthorized", { status: 401 });

const user = await prisma.user.findUnique({
  where: { email },
  select: { id: true, freeAttemptsUsed: true, freeAttemptCap: true, subscriptionStatus: true },
});
if (!user) return new Response("Unauthorized", { status: 401 });

const isPro =
  user.subscriptionStatus === "active" || user.subscriptionStatus === "trialing";

if (!isPro && user.freeAttemptsUsed >= user.freeAttemptCap) {
  return new Response(
    JSON.stringify({
      error: "FREE_LIMIT_REACHED",
      message: "You’ve used your free attempts. Upgrade to keep practicing.",
    }),
    { status: 402, headers: { "Content-Type": "application/json" } }
  );
}


    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });



    const prompt = `
You are an interview coach. Give feedback on the candidate's answer.

JOB DESCRIPTION:
${jobDesc ?? ""}

QUESTION:
${question ?? ""}

CANDIDATE ANSWER (TRANSCRIPT):
${transcript}

FILLER WORD ANALYSIS (precomputed):
- total_fillers: ${fillerStats.total}
- words: ${fillerStats.wordCount}
- fillers_per_100_words: ${fillerStats.fillersPer100Words.toFixed(1)}

Use the filler word analysis to slightly influence the communication_score.
Frequent filler words should lower communication_score slightly, but should not dominate the overall score.



Grade STAR quality:
- situation/task/action/result are 0-10 based on clarity, specificity, and completeness.
- If an element is weak or missing, give it 0-3.
STAR scoring anchors (use these strictly):
0-2 = missing or extremely vague (no concrete detail)
3-4 = mentioned but unclear (generic, lacks context)
5-6 = present with some specifics (at least 1 concrete detail)
7-8 = strong and specific (clear details + logical flow)
9-10 = exceptional (highly specific + measurable impact + crisp phrasing)

For each STAR sub-score, base it on a specific detail from the transcript. If none exists, score must be 0-2.

When unsure between two scores, choose the LOWER score unless the transcript clearly supports the higher one.



Scoring guidance:
- Overall score should be driven mainly by STAR quality (about 70% weight).
- Communication_score reflects delivery clarity (fillers, structure, confidence).
- A strong STAR answer with clear results should lead to a high overall score.
- A missing Result or weak Action should significantly lower the overall score.

Also return "confidence_score" (1-10) based on delivery signals in the transcript:
- Higher if the candidate uses direct ownership language ("I led", "I implemented", "I improved")
- Lower if the answer contains hedging ("maybe", "kind of", "sort of", "I think"), uncertainty, or vagueness
- Lower if there are many filler words

Confidence_score is separate from STAR quality and communication_score.

Also return "confidence_explanation" (1-2 sentences) explaining WHY the candidate received that confidence score.
Reference specific language patterns from the transcript (e.g., hedging, ownership, clarity, filler usage).



Also return "star_missing" listing any STAR components that are missing or too vague.
Only include values from: ["situation","task","action","result"].
If all are present, return [].

Be specific to THIS answer and THIS job description; do not give generic STAR tips.

For each STAR advice item, include a short label: "What you said:" followed by a 3–10 word quote from the transcript (verbatim).
For keywords_used / keywords_missing: compare transcript to job description. A keyword counts as "used" if it appears verbatim or as a close variant (e.g., "schedule adherence" vs "adherence to schedule").

Return STRICT JSON with this exact shape (no extra keys, no markdown):

{
  "score": 1-10,
  "communication_score": 1-10,
  "confidence_score": 1-10,
  "confidence_explanation": "string",

  "star": {
    "situation": 0-10,
    "task": 0-10,
    "action": 0-10,
    "result": 0-10
  },

  "star_missing": ["situation" | "task" | "action" | "result"],

  "star_advice": {
    "situation": "string",
    "task": "string",
    "action": "string",
    "result": "string"
  },

  "strengths": ["string"],
  "improvements": ["string"],
  "better_answer": "string",
  "keywords_used": ["string"],
  "keywords_missing": ["string"]
}

Rules:
- strengths must be 3–5 items.
- improvements must be 3–5 items.
- keywords_missing must be 0–8 items.
- star_missing must be 0–4 items.
- better_answer must be 120–180 words.
- star_advice: 1–2 sentences per field, must reference something they said OR say "Not mentioned".
- Include "What you said:" + a 3–10 word verbatim quote inside each star_advice field.
- keywords_used must be 0–12 items (keywords from the job description that ARE present in the transcript).
- keywords_missing must be 0–8 items (important keywords from the job description NOT present in the transcript).
- Prefer concrete terms (tools, metrics, processes) over generic words.





Do not include any extra text outside JSON.
`.trim();

    const resp = await client.responses.create({
      model: "gpt-4.1-mini",
      input: prompt,
      temperature: 0,
    });

    const text = resp.output_text?.trim() ?? "";

    // 1) Try direct parse
    let json = tryParseJson(text);

    // 2) If that fails, extract JSON and parse it
    if (!json) {
      const candidate = extractFirstJsonObject(text);
      if (candidate) json = tryParseJson(candidate);
    }
  if (!json) {
  return new Response(
    JSON.stringify({ error: "Model returned non-JSON output.", raw: text }),
    { status: 500, headers: { "Content-Type": "application/json" } }
  );
}


    // 3) Validate shape
    if (!validateFeedbackShape(json)) {
      return new Response(
        JSON.stringify({ error: "Model returned invalid JSON shape.", raw: text, parsed: json }),
        { status: 500, headers: { "Content-Type": "application/json" } }
      );
    }

    await prisma.user.update({
  where: { id: user.id },
  data: { freeAttemptsUsed: { increment: 1 } },
});

   return new Response(
  JSON.stringify({
    ...json,
    filler: {
      total: fillerStats.total,
      words: fillerStats.wordCount,
      per100: Number(fillerStats.fillersPer100Words.toFixed(1)),
      top: topFillers,
    },
    keywords_used: kw.keywords_used,
    keywords_missing: kw.keywords_missing,
  }),
  {
    status: 200,
    headers: { "Content-Type": "application/json" },
  }
);

 



  } catch (err: any) {
    return new Response(JSON.stringify({ error: err?.message ?? "Unknown error" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
}
