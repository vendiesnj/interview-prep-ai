// app/api/auth/[...nextauth]/route.ts
import NextAuth from "next-auth";
import type { NextAuthOptions } from "next-auth";
import GoogleProvider from "next-auth/providers/google";
import CredentialsProvider from "next-auth/providers/credentials";
import { PrismaAdapter } from "@next-auth/prisma-adapter";
import { prisma } from "@/app/lib/prisma";
import bcrypt from "bcryptjs";

export const authOptions: NextAuthOptions = {
debug: true,
logger: {
  error(code, metadata) {
    console.error("NEXTAUTH_ERROR", code, metadata);
  },
  warn(code) {
    console.warn("NEXTAUTH_WARN", code);
  },
  debug(code, metadata) {
    console.log("NEXTAUTH_DEBUG", code, metadata);
  },
},

  adapter: PrismaAdapter(prisma),
  session: {
    strategy: "jwt",
  },
  providers: [
    GoogleProvider({
  clientId: process.env.GOOGLE_CLIENT_ID!,
  clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
  authorization: {
    params: {
      prompt: "select_account", // forces the chooser
    },
  },
}),
    CredentialsProvider({
      name: "Email & Password",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) return null;

        const user = await prisma.user.findUnique({
          where: { email: credentials.email },
        });

        if (!user || !user.passwordHash) return null;

        const valid = await bcrypt.compare(
          credentials.password,
          user.passwordHash
        );

        if (!valid) return null;

        return {
          id: user.id,
          email: user.email,
          name: user.name,
        };
      },
    }),
  ],

  pages: {
    signIn: "/login",
  },
  // optional but useful while debugging
  // debug: true,
  // logger: {
  //   error(code, metadata) { console.error("NEXTAUTH_ERROR", code, metadata); },
  //   warn(code) { console.warn("NEXTAUTH_WARN", code); },
  //   debug(code, metadata) { console.log("NEXTAUTH_DEBUG", code, metadata); },
  // },
  secret: process.env.NEXTAUTH_SECRET,
};

// use the exported authOptions here
const handler = NextAuth(authOptions);

export { handler as GET, handler as POST };