export default function HistoryPage() {
  return (
    <div style={{ color: "#E5E7EB" }}>
      <h1 style={{ fontSize: 26, fontWeight: 950, margin: 0 }}>History</h1>
      <p style={{ marginTop: 10, color: "#9CA3AF" }}>
        Coming next: searchable attempts, trends, replay, and export.
      </p>
    </div>
  );
}
