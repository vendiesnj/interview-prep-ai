// app/api/billing/webhook/route.ts
import { NextResponse } from "next/server";
import Stripe from "stripe";
import { prisma } from "@/app/lib/prisma";

export const runtime = "nodejs";

// Create ONE Stripe client here (don’t import another "stripe" from lib in this file)
const stripeSecretKey = process.env.STRIPE_SECRET_KEY;
if (!stripeSecretKey) {
  throw new Error("Missing STRIPE_SECRET_KEY");
}
const stripe = new Stripe(stripeSecretKey);

// --- helpers ---
function asId(x: unknown): string | null {
  if (!x) return null;
  if (typeof x === "string") return x;
  if (typeof x === "object" && x !== null && "id" in x) {
    const id = (x as any).id;
    return typeof id === "string" ? id : null;
  }
  return null;
}

function unixToDate(sec: unknown): Date | null {
  return typeof sec === "number" ? new Date(sec * 1000) : null;
}

export async function POST(req: Request) {
  const sig = req.headers.get("stripe-signature");
  if (!sig) {
    return NextResponse.json({ error: "Missing stripe-signature" }, { status: 400 });
  }

  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!webhookSecret) {
    return NextResponse.json({ error: "Missing STRIPE_WEBHOOK_SECRET" }, { status: 500 });
  }

  const rawBody = await req.text();

  const ip =
    req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ??
    req.headers.get("x-real-ip") ??
    null;

  const userAgent = req.headers.get("user-agent") ?? null;

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(rawBody, sig, webhookSecret) as Stripe.Event;
  } catch (err: any) {
    return NextResponse.json(
      { error: `Webhook signature verification failed: ${err?.message ?? "unknown"}` },
      { status: 400 }
    );
  }

  const allowedTypes = new Set<string>([
    "checkout.session.completed",
    "customer.subscription.created",
    "customer.subscription.updated",
    "customer.subscription.deleted",
    "invoice.paid",
    "invoice.payment_succeeded",
    "invoice.payment_failed",
  ]);

  if (!allowedTypes.has(event.type)) {
    await prisma.auditLog
      .create({
        data: {
          action: "billing.webhook_ignored",
          ip,
          userAgent,
          meta: { eventId: event.id, type: event.type },
        },
      })
      .catch(() => {});
    return NextResponse.json({ received: true, ignored: true }, { status: 200 });
  }

  const eventId = event.id;

  // ---- idempotency ----
  const already = await prisma.stripeEvent.findUnique({
    where: { id: eventId },
    select: { id: true },
  });

  if (already) {
    await prisma.auditLog
      .create({
        data: {
          action: "billing.webhook_duplicate",
          ip,
          userAgent,
          meta: { eventId, type: event.type },
        },
      })
      .catch(() => {});
    return NextResponse.json({ received: true, duplicate: true }, { status: 200 });
  }

  await prisma.stripeEvent.create({ data: { id: eventId } });

  try {
    switch (event.type) {
      // ---------------------------
      // Checkout completed
      // ---------------------------
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;

        const customerId = asId(session.customer);
        const subscriptionId = asId((session as any).subscription);

        const userId =
          (typeof session.client_reference_id === "string" ? session.client_reference_id : null) ??
          (typeof (session.metadata as any)?.userId === "string" ? (session.metadata as any).userId : null);

        let priceId: string | null = null;
        let currentPeriodEnd: Date | null = null;

        if (subscriptionId) {
          const fullSub = await stripe.subscriptions.retrieve(subscriptionId);
          priceId = fullSub.items?.data?.[0]?.price?.id ?? null;
          currentPeriodEnd = unixToDate((fullSub as any).current_period_end);
        }

        if (userId) {
          await prisma.user.update({
            where: { id: userId },
            data: {
              subscriptionStatus: "active",
              ...(customerId ? { stripeCustomerId: customerId } : {}),
              ...(subscriptionId ? { stripeSubscriptionId: subscriptionId } : {}),
              ...(priceId ? { stripePriceId: priceId } : {}),
              currentPeriodEnd,
            },
          });
        } else if (customerId) {
          await prisma.user.updateMany({
            where: { stripeCustomerId: customerId },
            data: {
              subscriptionStatus: "active",
              ...(subscriptionId ? { stripeSubscriptionId: subscriptionId } : {}),
              ...(priceId ? { stripePriceId: priceId } : {}),
              currentPeriodEnd,
            },
          });
        }

        break;
      }

      // ---------------------------
      // Subscription lifecycle
      // ---------------------------
      case "customer.subscription.created":
      case "customer.subscription.updated":
      case "customer.subscription.deleted": {
        const sub = event.data.object as Stripe.Subscription;

        // Always retrieve for authoritative fields
        const subId = sub.id;
        const fullSub = await stripe.subscriptions.retrieve(subId);

        const status = fullSub.status ?? sub.status ?? "unknown";
        const customerId = asId(fullSub.customer) ?? asId(sub.customer);
        const subscriptionId = fullSub.id ?? sub.id;

        const userId =
          (typeof (fullSub.metadata as any)?.userId === "string" ? (fullSub.metadata as any).userId : null) ??
          (typeof (sub.metadata as any)?.userId === "string" ? (sub.metadata as any).userId : null);

        const priceId = fullSub.items?.data?.[0]?.price?.id ?? sub.items?.data?.[0]?.price?.id ?? null;
        const currentPeriodEnd = unixToDate((fullSub as any).current_period_end);

        const data = {
          subscriptionStatus: status,
          ...(customerId ? { stripeCustomerId: customerId } : {}),
          ...(subscriptionId ? { stripeSubscriptionId: subscriptionId } : {}),
          ...(priceId ? { stripePriceId: priceId } : {}),
          currentPeriodEnd,
        };

        if (userId) {
          await prisma.user.update({ where: { id: userId }, data });
        } else if (customerId) {
          await prisma.user.updateMany({ where: { stripeCustomerId: customerId }, data });
        }

        break;
      }

      // ---------------------------
      // Invoice success = keep user active + backfill end/price
      // ---------------------------
      case "invoice.paid":
      case "invoice.payment_succeeded": {
        const inv = event.data.object as Stripe.Invoice;

        const customerId = asId(inv.customer);
        const subscriptionId = asId((inv as any).subscription);

        let priceId: string | null = null;
        let currentPeriodEnd: Date | null = null;

        if (subscriptionId) {
          const fullSub = await stripe.subscriptions.retrieve(subscriptionId);
          priceId = fullSub.items?.data?.[0]?.price?.id ?? null;
          currentPeriodEnd = unixToDate((fullSub as any).current_period_end);
        }

        await prisma.user.updateMany({
          where: {
            OR: [
              ...(subscriptionId ? [{ stripeSubscriptionId: subscriptionId }] : []),
              ...(customerId ? [{ stripeCustomerId: customerId }] : []),
            ],
          },
          data: {
            subscriptionStatus: "active",
            ...(customerId ? { stripeCustomerId: customerId } : {}),
            ...(subscriptionId ? { stripeSubscriptionId: subscriptionId } : {}),
            ...(priceId ? { stripePriceId: priceId } : {}),
            currentPeriodEnd,
          },
        });

        break;
      }

      // ---------------------------
      // Invoice failed = mark past_due
      // ---------------------------
      case "invoice.payment_failed": {
        const inv = event.data.object as Stripe.Invoice;

        const customerId = asId(inv.customer);
        const subscriptionId = asId((inv as any).subscription);

        await prisma.user.updateMany({
          where: {
            OR: [
              ...(subscriptionId ? [{ stripeSubscriptionId: subscriptionId }] : []),
              ...(customerId ? [{ stripeCustomerId: customerId }] : []),
            ],
          },
          data: { subscriptionStatus: "past_due" },
        });

        break;
      }

      default:
        break;
    }

    await prisma.auditLog
      .create({
        data: {
          action: "billing.webhook_processed",
          ip,
          userAgent,
          meta: { eventId, type: event.type },
        },
      })
      .catch(() => {});

    return NextResponse.json({ received: true }, { status: 200 });
  } catch (err: any) {
    // if we fail, remove idempotency marker so Stripe can retry
    await prisma.stripeEvent.delete({ where: { id: eventId } }).catch(() => {});

    await prisma.auditLog
      .create({
        data: {
          action: "billing.webhook_error",
          ip,
          userAgent,
          meta: {
            type: event?.type ?? null,
            eventId: event?.id ?? null,
            message: err?.message ?? "unknown",
          },
        },
      })
      .catch(() => {});

    return NextResponse.json(
      { error: `Webhook handler failed: ${err?.message ?? "unknown"}` },
      { status: 500 }
    );
  }
}