// app/api/billing/webhook/route.ts
import { NextResponse } from "next/server";
import { stripe } from "@/app/lib/stripe";
import { prisma } from "@/app/lib/prisma";

export const runtime = "nodejs";

export async function POST(req: Request) {
  const sig = req.headers.get("stripe-signature");
  if (!sig) {
    return NextResponse.json({ error: "Missing stripe-signature" }, { status: 400 });
  }

  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!webhookSecret) {
    return NextResponse.json({ error: "Missing STRIPE_WEBHOOK_SECRET" }, { status: 500 });
  }

  // Stripe needs the RAW body for signature verification
  const rawBody = await req.text();

  const ip =
  req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ??
  req.headers.get("x-real-ip") ??
  null;

const userAgent = req.headers.get("user-agent") ?? null;

  let event: any;
  try {
    event = stripe.webhooks.constructEvent(rawBody, sig, webhookSecret);
  } catch (err: any) {
    return NextResponse.json(
      { error: `Webhook signature verification failed: ${err?.message ?? "unknown"}` },
      { status: 400 }
    );
  }

  const allowedTypes = new Set([
  "checkout.session.completed",
  "customer.subscription.created",
  "customer.subscription.updated",
  "customer.subscription.deleted",
]);

if (!allowedTypes.has(event.type)) {
  await prisma.auditLog
    .create({
      data: {
        action: "billing.webhook_ignored",
        ip,
        userAgent,
        meta: { eventId: event.id, type: event.type },
      },
    })
    .catch(() => {});
  return NextResponse.json({ received: true, ignored: true }, { status: 200 });
}

  
  try {
    // Idempotency: Stripe may retry events. Process each event.id only once.
const eventId = event.id as string | undefined;
if (!eventId) {
  return NextResponse.json({ error: "Missing event.id" }, { status: 400 });
}

// If we've already processed this Stripe event, acknowledge immediately.
const already = await prisma.stripeEvent.findUnique({
  where: { id: eventId },
  select: { id: true },
});

if (already) {
  await prisma.auditLog
    .create({
      data: {
        action: "billing.webhook_duplicate",
        ip,
        userAgent,
        meta: { eventId, type: event.type },
      },
    })
    .catch(() => {});
  return NextResponse.json({ received: true, duplicate: true }, { status: 200 });
}

// Mark as processed BEFORE handling, so concurrent deliveries don't double-run.
await prisma.stripeEvent.create({
  data: { id: eventId },
});

try {
    switch (event.type) {
      // User finished Checkout (subscription or payment)
      case "checkout.session.completed": {
        const session = event.data.object as any;

        const customerId = (session.customer as string | null) ?? null;

// Prefer user mapping via Checkout Session fields
const userId =
  (session.client_reference_id as string | null) ??
  ((session.metadata?.userId as string | undefined) ?? null);

const subscriptionId = (session.subscription as string | null) ?? null;

// If we know the userId, update that user directly (most reliable)
if (userId) {
  await prisma.user.update({
    where: { id: userId },
    data: {
      subscriptionStatus: "active",
      ...(customerId ? { stripeCustomerId: customerId } : {}),
      ...(subscriptionId ? { stripeSubscriptionId: subscriptionId } : {}),
    },
  });
} else if (customerId) {
  // Fallback to customerId mapping (older sessions)
  await prisma.user.updateMany({
    where: { stripeCustomerId: customerId },
    data: {
      subscriptionStatus: "active",
      ...(subscriptionId ? { stripeSubscriptionId: subscriptionId } : {}),
    },
  });
}

break;
      }

      // Subscription lifecycle changes
      case "customer.subscription.created":
      case "customer.subscription.updated":
      case "customer.subscription.deleted": {
       const sub = event.data.object as any;

const customerId = (sub.customer as string | null) ?? null;
const subscriptionId = (sub.id as string | null) ?? null;
const status = (sub.status as string | null) ?? "unknown";

// Prefer user mapping via Subscription metadata (we set this during checkout)
const userId = ((sub.metadata?.userId as string | undefined) ?? null);

const priceId = sub.items?.data?.[0]?.price?.id ?? null;

const currentPeriodEnd =
  typeof sub.current_period_end === "number"
    ? new Date(sub.current_period_end * 1000)
    : null;

const data = {
  subscriptionStatus: status,
  ...(subscriptionId ? { stripeSubscriptionId: subscriptionId } : {}),
  ...(priceId ? { stripePriceId: priceId } : {}),
  ...(currentPeriodEnd ? { currentPeriodEnd } : {}),
  ...(customerId ? { stripeCustomerId: customerId } : {}),
};

// If we know the userId, update that user directly
if (userId) {
  await prisma.user.update({
    where: { id: userId },
    data,
  });
} else if (customerId) {
  // Fallback for older subs that don't have metadata
  await prisma.user.updateMany({
    where: { stripeCustomerId: customerId },
    data,
  });
}

break; 
      }
default:
  // ignore other events for now
  break;
}
} catch (err) {
  // If processing failed, remove the idempotency marker so Stripe retries can succeed.
  await prisma.stripeEvent.delete({ where: { id: eventId } }).catch(() => {});
  throw err;
}

await prisma.auditLog
  .create({
    data: {
      action: "billing.webhook_processed",
      ip,
      userAgent,
      meta: { eventId, type: event.type },
    },
  })
  .catch(() => {});

return NextResponse.json({ received: true }, { status: 200 });
     
  } catch (err: any) {
  // Best-effort audit log so you can debug production issues fast
  await prisma.auditLog
    .create({
      data: {
        action: "billing.webhook_error",
        ip,
        userAgent,
        meta: {
          type: event?.type ?? null,
          eventId: event?.id ?? null,
          message: err?.message ?? "unknown",
        },
      },
    })
    .catch(() => {});

  return NextResponse.json(
    { error: `Webhook handler failed: ${err?.message ?? "unknown"}` },
    { status: 500 }
  );
}
}