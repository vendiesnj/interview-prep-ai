import OpenAI from "openai";

export const runtime = "nodejs";

export async function POST(req: Request) {
  try {
    const formData = await req.formData();
    const audio = formData.get("audio");
    const durationRaw = formData.get("duration");
const durationSeconds =
  typeof durationRaw === "string" ? Number(durationRaw) : null;


    if (!audio || !(audio instanceof File)) {
      return new Response(JSON.stringify({ error: "Missing audio file." }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      });
    }

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

    const transcript = await client.audio.transcriptions.create({
      file: audio,
      model: "whisper-1",
    });
    
    return new Response(
  JSON.stringify({ text: transcript.text, durationSeconds }),
  {
    status: 200,
    headers: { "Content-Type": "application/json" },
  }
);

    
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err?.message ?? "Unknown error" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
}
